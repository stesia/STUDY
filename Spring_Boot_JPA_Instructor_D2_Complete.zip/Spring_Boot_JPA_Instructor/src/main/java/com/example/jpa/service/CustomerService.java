package com.example.jpa.service;

import com.example.jpa.entity.CustomerDto;

public interface CustomerService {
	CustomerDto createCustomer(CustomerDto dto);
}
